//
//  Conflict.swift
//  Project1
//
//  Created by user157788 on 10/3/19.
//  Copyright © 2019 paulrich. All rights reserved.
//

import Foundation
class Conflict {
    var ownedPet: Pet
    var wildPet: Pet
    
    var move1: Move?
    var move2: Move?
    
    init(_ p1: Pet, _ p2: Pet) {
        self.ownedPet = p1
        self.wildPet = p2
    }
    
    func setMove1(_ m: Move?) {
        move1 = m
    }
    func setMove2(_ m: Move?) {
        move2 = m
    }
    
    func setConflict() -> Bool {
        let dmgs = calcDmg()
        move1?.performAction()
        move2?.performAction()
        return engage(dmg1: dmgs.0, dmg2: dmgs.1)
    }
    func engage(dmg1: Double, dmg2: Double) -> Bool {
        switch move1!.priority {
        case true where move2!.priority == false:
            ownedFirst(dmg1)
            wildFirst(dmg2)
            return true
        case false where move2!.priority == true:
            wildFirst(dmg2)
            ownedFirst(dmg1)
            return false
        default:
            print("Speed default")
            print(ownedPet.spd, wildPet.spd)
            if ownedPet.spd > wildPet.spd {
                ownedFirst(dmg1)
                wildFirst(dmg2)
                return true
            }
            else if ownedPet.spd < wildPet.spd {
                wildFirst(dmg2)
                ownedFirst(dmg1)
                return false
            }
            else {
                let rand = Bool.random()
                if rand {
                    ownedFirst(dmg1)
                    wildFirst(dmg2)
                    return true
                }
                else {
                    wildFirst(dmg2)
                    ownedFirst(dmg1)
                    return false
                }
            }
        }
    }
    
    func ownedFirst(_ dmg: Double) {
        move1?.performAction()
        var damage = dmg
        if wildPet.type == move1?.type {
            damage *= 0.75
        }
        wildPet.actHP -= damage
        wildPet.actHP = wildPet.actHP.truncate(to: 0)
    }
    func wildFirst(_ dmg: Double) {
        move2?.performAction()
        var damage = dmg
        if ownedPet.type == move2?.type {
            damage *= 0.75
        }
        ownedPet.actHP -= damage
        ownedPet.actHP = ownedPet.actHP.truncate(to: 0)
    }
    
    func calcDmg() -> (Double, Double) {
        var dmg1: Double = ((2.0 * Double(ownedPet.level)) / 5.0) + 2
        dmg1 *= move1!.power
        dmg1 *= (ownedPet.atk / wildPet.def)
        dmg1 /= 50
        //dmg1 += 2
        dmg1 *= move1!.modifier.rawValue
        
        var dmg2: Double = ((2.0 * Double(wildPet.level)) / 5.0) + 2
        dmg2 *= move2!.power
        dmg2 *= (ownedPet.atk / wildPet.def)
        dmg2 /= 50
        //dmg2 += 2
        dmg2 *= move2!.modifier.rawValue
        
        calcResist(dmg1: &dmg1, dmg2: &dmg2)
        
        return (dmg1, dmg2)
    }
    
    func calcResist(dmg1: inout Double, dmg2: inout Double) {
        switch move1?.type {
        case "Fire":
            if wildPet.type == "Water" {
                dmg1 *= 0.85
            }
            else if wildPet.type == "Grass" {
                dmg1 *= 1.15
            }
            else {
                dmg1 *= 1.0
            }
        case "Water":
            if wildPet.type == "Fire" {
                dmg1 *= 1.15
            }
            else if wildPet.type == "Grass" {
                dmg1 *= 0.85
            }
            else {
                dmg1 *= 1.0
            }
        case "Grass":
            if wildPet.type == "Water" {
                dmg1 *= 1.15
            }
            else if wildPet.type == "Fire" {
                dmg1 *= 0.85
            }
            else {
                dmg1 *= 1.0
            }
        default:
            dmg1 *= 1.0
        }
        
        switch move2?.type {
        case "Fire":
            if ownedPet.type == "Water" {
                dmg2 *= 0.85
            }
            else if ownedPet.type == "Grass" {
                dmg2 *= 1.15
            }
            else {
                dmg2 *= 1.0
            }
        case "Water":
            if ownedPet.type == "Fire" {
                dmg2 *= 1.15
            }
            else if ownedPet.type == "Grass" {
                dmg2 *= 0.85
            }
            else {
                dmg2 *= 1.0
            }
        case "Grass":
            if ownedPet.type == "Water" {
                dmg2 *= 1.15
            }
            else if ownedPet.type == "Fire" {
                dmg2 *= 0.85
            }
            else {
                dmg2 *= 1.0
            }
        default:
            dmg2 *= 1.0
        }
    }
    
}
