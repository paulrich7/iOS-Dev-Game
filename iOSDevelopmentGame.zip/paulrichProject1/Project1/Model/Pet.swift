//
//  Pet.swift
//  Project1
//
//  Created by user157788 on 10/22/19.
//  Copyright © 2019 paulrich. All rights reserved.
//

import Foundation
import UIKit

extension Double {

    func truncate(to places: Int) -> Double {

        let newDecimal = pow(10, Double(places)) * self
        let truncated = Double(Int(newDecimal))
        let originalDecimal = truncated / pow(10, Double(places))
        return originalDecimal

    }

}

class Pet {
    var name: String
    var level: Int
    var image: UIImage
    var type: String
    var hp: Double
    var atk: Double
    var def: Double
    var spd: Double
    
    var actHP = 0.0
    
    var m1: Move? = nil
    var m2: Move? = nil
    var m3: Move? = nil
    var m4: Move? = nil
    
    init(_ n: String, _ l: Int, _ i: UIImage, _ h: Double, _ a: Double, _ d: Double, _ s: Double, _ t: String)
                  /*_ m1: Move, _ m2: Move, _ m3: Move, _ m4: Move)*/{
        
        self.name = n
        self.level = l
        self.image = i
        self.hp = h
        self.atk = a
        self.def = d
        self.spd = s
        self.type = t
    }
    
    func calcRealHP() -> Int? {
        actHP = (hp * 2.0)
        actHP *= Double(level)
        actHP /= 100.0
        actHP += Double(level)
        actHP += 10
        actHP = actHP.truncate(to: 0)
        return Int(actHP)
    }
}
