//
//  Moves.swift
//  Project1
//
//  Created by user157788 on 12/3/19.
//  Copyright © 2019 paulrich. All rights reserved.
//

import Foundation
import UIKit

class SwordsDance: Move {
    init(_ owner: Pet) {
        super.init("Swords Dance", 0.0, 1.00, "Normal", false, 32, owner, Modifier.nonAtk, CIColor.gray)
    }
    override func performAction() {
        owner.atk *= 1.25
        pp -= 1
    }
}

class FireFang: Move {
    init(_ owner: Pet) {
        if owner.type == "Fire" {
            super.init("Fire Fang", 65.0, 0.95, "Fire", false, 15, owner, Modifier.stab, CIColor.init(red: 1, green: 0.5, blue: 0))
        }
        else {
            super.init("Fire Fang", 65.0, 0.95, "Fire", false, 15, owner, Modifier.normal, CIColor.init(red: 1, green: 0.5, blue: 0))
        }
    }
}

class QuickAttack: Move {
    init(_ owner: Pet) {
        if owner.type == "Normal" {
            super.init("Quick Attack", 40.0, 1.00, "Normal", true, 30, owner, Modifier.stab, CIColor.gray)
        }
        else {
            super.init("Quick Attack", 40.0, 1.00, "Normal", true, 30, owner, Modifier.normal, CIColor.gray)
        }
    }
}

class Crunch: Move {
    init(_ owner: Pet) {
        if owner.type == "Dark" {
            super.init("Crunch", 80.0, 1.00, "Dark", false, 15, owner, Modifier.stab, CIColor.black)
        }
        else {
            super.init("Crunch", 80.0, 1.00, "Dark", false, 15, owner, Modifier.normal, CIColor.black)
        }
    }
}

class AquaTail: Move {
    init(_ owner: Pet) {
        if owner.type == "Water" {
            super.init("Aqua Tail", 90.0, 0.90, "Water", false, 10, owner, Modifier.stab, CIColor.init(red: 0, green: 0, blue: 0.5))
        }
        else {
            super.init("Aqua Tail", 90.0, 0.90, "Water", false, 10, owner, Modifier.normal, CIColor.init(red: 0, green: 0, blue: 0.5))
        }
    }
}

class WaterFall: Move {
    init(_ owner: Pet) {
        if owner.type == "Water" {
            super.init("Waterfall", 80.0, 1.00, "Water", false, 15, owner, Modifier.stab, CIColor.init(red: 0, green: 0, blue: 0.5))
        }
        else {
            super.init("Waterfall", 80.0, 1.00, "Water", false, 15, owner, Modifier.normal, CIColor.init(red: 0, green: 0, blue: 0.5))
        }
    }
}

class VineWhip: Move {
    init(_ owner: Pet) {
        if owner.type == "Grass" {
            super.init("Vine Whip", 45.0, 1.00, "Grass", false, 25, owner, Modifier.stab, CIColor.init(red: 0, green: 0.5, blue: 0))
        }
        else {
            super.init("Vine Whip", 45.0, 1.00, "Grass", false, 25, owner, Modifier.normal, CIColor.init(red: 0, green: 0.5, blue: 0))
        }
    }
}

class LeafBlade: Move {
    init(_ owner: Pet) {
        if owner.type == "Grass" {
            super.init("Leaf Blade", 90.0, 1.00, "Grass", false, 15, owner, Modifier.stab, CIColor.init(red: 0, green: 0.5, blue: 0))
        }
        else {
            super.init("Leaf Blade", 90.0, 1.00, "Grass", false, 15, owner, Modifier.normal, CIColor.init(red: 0, green: 0.5, blue: 0))
        }
    }
}

class DragonTail: Move {
    init(_ owner: Pet) {
        if owner.type == "Dragon" {
            super.init("Dragon Tail", 60.0, 0.90, "Dragon", false, 10, owner, Modifier.stab, CIColor.init(red: 0.5, green: 0, blue: 0.5))
        }
        else {
            super.init("Dragon Tail", 60.0, 0.90, "Dragon", false, 10, owner, Modifier.normal, CIColor.init(red: 0.5, green: 0, blue: 0.5))
        }
    }
}
