//
//  Locate.swift
//  Project1
//
//  Created by user157788 on 11/21/19.
//  Copyright © 2019 paulrich. All rights reserved.
//

import Foundation

class Locate: Codable {
    var x: Int
    var y: Int
    
    init(x: Int, y: Int) {
        self.x = x
        self.y = y
    }
}
