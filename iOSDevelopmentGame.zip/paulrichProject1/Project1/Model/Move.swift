//
//  Move.swift
//  Project1
//
//  Created by user157788 on 12/2/19.
//  Copyright © 2019 paulrich. All rights reserved.
//

import Foundation
import UIKit

enum Modifier: Double {
    case nonAtk = 0.0
    case normal = 1.0
    case stab = 1.5
}

class Move {
    var name: String
    var power: Double
    var acc: Double
    var type: String
    var priority: Bool
    var pp: Int
    var owner: Pet
    var modifier: Modifier
    var color: CIColor
    
    init(_ n: String, _ p: Double, _ a: Double, _ t: String, _ prio: Bool, _ pp: Int, _ o: Pet, _ m: Modifier, _ c: CIColor) {
        self.power = p
        self.acc = a
        self.type = t
        self.name = n
        self.priority = prio
        self.pp = pp
        self.owner = o
        self.modifier = m
        self.color = c
    }
    
    func performAction() {
        pp -= 1
    }
}
