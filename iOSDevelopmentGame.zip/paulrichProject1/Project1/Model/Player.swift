//
//  Player.swift
//  Project1
//
//  Created by user157788 on 10/3/19.
//  Copyright © 2019 paulrich. All rights reserved.
//

import Foundation
class Player {
    private
    var hp = 100
    var atk = 0
    var def = 0
    var spd = 0
    
    var lineup: Array<Pet> = []
    
    public
    init(hp: Int, atk: Int, def: Int, spd: Int){
        self.hp = hp
        self.atk = atk
        self.def = def
        self.spd = spd
    }
    
    func addPet(_ p: Pet) {
        lineup.append(p)
    }
    
    func takeDamage(dmg: Int) -> Void {
        if dmg < def {
            return
        }
        else {
            let dmgTaken = dmg - def
            hp -= dmgTaken
        }
        
    }
    func getHp() -> Int {
        return hp
    }
    
    func incAtk(amt: Int) -> Void {
        atk += amt
    }
    func getAtk() -> Int {
        return atk
    }
    
    func incDef(amt: Int) -> Void {
        def += amt
    }
    func getDef() -> Int {
        return def
    }
    
    func setSpd(amt: Int) -> Void {
        spd = amt
    }
    func getSpd() -> Int {
        return spd
    }
    
    func reset() -> Void {
        hp = 100
        atk = 0
        def = 0
        spd = 0
    }
}
