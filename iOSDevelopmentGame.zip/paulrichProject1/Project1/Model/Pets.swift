//
//  Pets.swift
//  Project1
//
//  Created by user157788 on 12/3/19.
//  Copyright © 2019 paulrich. All rights reserved.
//

import Foundation
import UIKit

class Arcanine: Pet {
    init() {
        super.init("Arcanine", 50, UIImage(named: "arcanine")!, 90.0, 110.0, 80.0, 95.0, "Fire")
        m1 = SwordsDance(self)
        m2 = FireFang(self)
        m3 = QuickAttack(self)
        m4 = Crunch(self)
    }
}

class Feraligatr: Pet {
    init() {
        super.init("Feraligatr", 50, UIImage(named: "feraligatr")!, 85.0, 105.0, 100.0, 78.0, "Water")
        m1 = SwordsDance(self)
        m2 = AquaTail(self)
        m3 = WaterFall(self)
        m4 = Crunch(self)
    }
}

class Serperior: Pet {
    init() {
        super.init("Serperior", 50, UIImage(named: "serperior")!, 75.0, 75.0, 95.0, 113.0, "Grass")
        m1 = SwordsDance(self)
        m2 = VineWhip(self)
        m3 = LeafBlade(self)
        m4 = DragonTail(self)
    }
}
