//
//  WorldViewController.swift
//  Project1
//
//  Created by user157788 on 10/22/19.
//  Copyright © 2019 paulrich. All rights reserved.
//

import UIKit
class WorldViewController: UIViewController, WorldViewControllerDelegate {
    
    struct Encounter {
        var encounterX: Int
        var encounterY: Int
        var encounterPet: Pet?
    }
    
    @IBOutlet weak var currentPetLabel: UILabel!
    @IBOutlet weak var currentPetImg: UIImageView!
    
    let upAnim = ["u1", "u2", "u3", "u4", "u5", "u4", "u3", "u2"]
    let downAnim = ["d1", "d2", "d3", "d4", "d5", "d4", "d3", "d2"]
    let rightAnim = ["right1", "right2", "right3", "right4", "right5", "right6"]
    let leftAnim = ["left1", "left2", "left3", "left4", "left5", "left6"]
    let idleAnim = ["standing_rightanddown"/*, "standing_left"*/]
    let background = ["marsh", "sand", "grass.jpg"]
    let pets = [Feraligatr(), Arcanine(), Serperior()]
    var playerPet: Pet = Arcanine()
    var saveNum: Int = 0
    var animCount = 0
    var backImage: String?
    
    enum Direction: Int {
        case up = 0
        case right
        case down
        case left
    }
    var direction = Direction.down.rawValue
    
    var xPos = 50
    var yPos = 50
    var oldX = 50
    var oldY = 50
    let animW = 50
    let animH = 50
    let moveSpeed = 10
    var maxX: Int = 0
    var maxY: Int = 0
    var minX: Int = 0
    var minY: Int = 0
    
    var encounter = Encounter(encounterX: 0, encounterY: 0, encounterPet: nil)
    
    var moving = false
    var moveCount = 0
    
    
    @IBOutlet weak var animView: UIImageView!
    
    var timer = Timer()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        timer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(animateSprite), userInfo: nil, repeats: true)
        
        loadData()
        
        //let rand = Int.random(in: 0...2)
//        saveNum = rand
        backImage = background[saveNum]
        encounter = Encounter.init(encounterX: 100, encounterY: 100, encounterPet: pets[saveNum])
        currentPetImg.image = playerPet.image
        
        
//        xPos = loc.x
//        yPos = loc.y
        oldX = xPos
        oldY = yPos
        animView.frame = CGRect(x: xPos, y: yPos, width: animW, height: animH)
        maxX = Int(view.bounds.maxX) - 50
        maxY = Int(view.bounds.maxY) - 50
        minX = Int(view.bounds.minX) - 50
        minY = Int(view.bounds.minX) - 50
        
        NotificationCenter.default.addObserver(self, selector: #selector(saveData), name: UIApplication.willResignActiveNotification, object: nil)
        
        UIGraphicsBeginImageContext(self.view.frame.size)
        UIImage(named: backImage!)?.draw(in: self.view.bounds)

        if let image = UIGraphicsGetImageFromCurrentImageContext(){
            UIGraphicsEndImageContext()
            self.view.backgroundColor = UIColor(patternImage: image)
        }else{
            UIGraphicsEndImageContext()
            debugPrint("Image not available")
        }
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func menuSegueButton(_ sender: UIButton) {
        saveData()
        self.performSegue(withIdentifier: "MenuSegue", sender: sender)
    }
    
    @objc func saveData() {
        let loc = Locate(x: xPos, y: yPos)
        let num = saveNum
        do {
            let locData = try JSONEncoder().encode(loc)
            UserDefaults.standard.set(locData, forKey: "loc")
            let numData = try JSONEncoder().encode(num)
            UserDefaults.standard.set(numData, forKey: "num")
            print("Saved Data")
        }
        catch {
            print("Error in saveData")
        }
    }
    
    func loadData() {
        if let locData = UserDefaults.standard.data(forKey: "loc") {
            do {
                let loc = try JSONDecoder().decode(Locate.self, from: locData)
                xPos = loc.x
                yPos = loc.y
                print("x\(loc.x), y\(loc.y)")
                print("Loaded Data")
            }
            catch {
                print("Error in loadData")
            }
        }
        if let numData = UserDefaults.standard.data(forKey: "num") {
            do {
                let num = try JSONDecoder().decode(Int.self, from: numData)
                saveNum = num
                print("SaveNum \(num)")
            }
            catch {
                print("Error in loadData")
            }
        }
    }
    
    @objc func animateSprite(){
        var anim:[String]
        
        if (abs(xPos - oldX) < 30) && (abs(yPos - oldY) < 30) {
            moveCount += 1
        }
        
        if moveCount < 3 {
            switch direction {
            case Direction.up.rawValue:
                anim = upAnim
            case Direction.right.rawValue:
                anim = rightAnim
            case Direction.down.rawValue:
                anim = downAnim
            case Direction.left.rawValue:
                anim = leftAnim
            default:
                anim = idleAnim
            }
        }
        else {
            anim = idleAnim
        }
        
        if animCount >= anim.count {
            animCount = 0
        }
        animView.image = UIImage(named: anim[animCount])
        animCount += 1
        
    }
    
    @IBAction func startEncounter(sender: UIButton) {
        self.performSegue(withIdentifier: "EncounterSegue", sender: sender)
    }

    
    @IBAction func ButtonPress(_ sender: UILongPressGestureRecognizer) {
        
        moving = true
        moveCount = 0
        switch sender.allowableMovement {
        case 100:
            oldY = yPos
            yPos -= moveSpeed
            direction = Direction.up.rawValue
            switchScreen(vertical: true)
        case 101:
            oldX = xPos
            xPos += moveSpeed
            direction = Direction.right.rawValue
            switchScreen(vertical: false)
        case 102:
            oldY = yPos
            yPos += moveSpeed
            direction = Direction.down.rawValue
            switchScreen(vertical: true)
        case 103:
            oldX = xPos
            xPos -= moveSpeed
            direction = Direction.left.rawValue
            switchScreen(vertical: false)
        default:
            print("ERROR: No Valid Direction")
        }
        animView.frame = CGRect(x: xPos, y: yPos, width: animW, height: animH)
        print(xPos, yPos)
        if (abs(xPos - encounter.encounterX) <= 75) && (abs(yPos - encounter.encounterY) <= 75) {
            encounter.encounterX = 0
            encounter.encounterY = 0
            saveData()
            self.performSegue(withIdentifier: "EncounterSegue", sender: self)
            moving = false
        }
    }
    
    @IBAction func tapButton(_ sender: UITapGestureRecognizer) {
    }
    
    func switchScreen(vertical: Bool) {
        if vertical {
            if yPos <= 20 {
                yPos = maxY - 20
                encounter.encounterX = Int.random(in: 100...(maxX - 50))
                encounter.encounterY = Int.random(in: 100...(maxY - 50))
                
                let rand = Int.random(in: 0...2)
                saveNum = rand
                backImage = background[rand]
                encounter.encounterPet = pets[rand]
                UIGraphicsBeginImageContext(self.view.frame.size)
                UIImage(named: backImage!)?.draw(in: self.view.bounds)

                if let image = UIGraphicsGetImageFromCurrentImageContext(){
                    UIGraphicsEndImageContext()
                    self.view.backgroundColor = UIColor(patternImage: image)
                }else{
                    UIGraphicsEndImageContext()
                    debugPrint("Image not available")
                }
                
            }
            else if yPos >= maxY {
                yPos = 50
                encounter.encounterX = Int.random(in: 100...(maxX - 50))
                encounter.encounterY = Int.random(in: 100...(maxY - 50))
                
                let rand = Int.random(in: 0...2)
                saveNum = rand
                backImage = background[rand]
                encounter.encounterPet = pets[rand]
                UIGraphicsBeginImageContext(self.view.frame.size)
                UIImage(named: backImage!)?.draw(in: self.view.bounds)

                if let image = UIGraphicsGetImageFromCurrentImageContext(){
                    UIGraphicsEndImageContext()
                    self.view.backgroundColor = UIColor(patternImage: image)
                }else{
                    UIGraphicsEndImageContext()
                    debugPrint("Image not available")
                }
            }
        }
        else {
            if xPos <= 20 {
                xPos = maxX - 20
                encounter.encounterX = Int.random(in: 100...(maxX - 50))
                encounter.encounterY = Int.random(in: 100...(maxY - 50))
                
                let rand = Int.random(in: 0...2)
                saveNum = rand
                backImage = background[rand]
                encounter.encounterPet = pets[rand]
                UIGraphicsBeginImageContext(self.view.frame.size)
                UIImage(named: backImage!)?.draw(in: self.view.bounds)

                if let image = UIGraphicsGetImageFromCurrentImageContext(){
                    UIGraphicsEndImageContext()
                    self.view.backgroundColor = UIColor(patternImage: image)
                }else{
                    UIGraphicsEndImageContext()
                    debugPrint("Image not available")
                }
            }
            else if xPos >= maxX {
                xPos = 30
                encounter.encounterX = Int.random(in: 100...(maxX - 50))
                encounter.encounterY = Int.random(in: 100...(maxY - 50))
                
                let rand = Int.random(in: 0...2)
                saveNum = rand
                backImage = background[rand]
                encounter.encounterPet = pets[rand]
                UIGraphicsBeginImageContext(self.view.frame.size)
                UIImage(named: backImage!)?.draw(in: self.view.bounds)

                if let image = UIGraphicsGetImageFromCurrentImageContext(){
                    UIGraphicsEndImageContext()
                    self.view.backgroundColor = UIColor(patternImage: image)
                }else{
                    UIGraphicsEndImageContext()
                    debugPrint("Image not available")
                }
            }
        }
        
        print("Encounter Loc:")
        print(encounter.encounterX, encounter.encounterY)
        saveData()
    }
    
    func setNewPlayerPet(_ controller: MenuViewController, _ pet: Pet) {
        self.playerPet = pet
        currentPetImg.image = playerPet.image
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.destination is ViewController {
            let vc = segue.destination as? ViewController
            vc?.ownedPet = playerPet
            vc?.wildPet = encounter.encounterPet
            vc?.backImage = backImage!
            
        }
        else if segue.destination is MenuViewController {
            let vc = segue.destination as? MenuViewController
            vc?.delegate = self
        }
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }

}
