//
//  MenuViewController.swift
//  Project1
//
//  Created by user157788 on 10/8/19.
//  Copyright © 2019 paulrich. All rights reserved.
//

import UIKit

class MenuViewController: UIViewController {
    
    var delegate: WorldViewControllerDelegate?
    
    @IBOutlet weak var segueBack: UIButton!
    
    @IBOutlet var arcanineButtons: [UIButton]!
    
    @IBOutlet var feraligatrButtons: [UIButton]!
    
    @IBOutlet var serperiorButtons: [UIButton]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        segueBack.layer.cornerRadius = 20
        segueBack.setTitle("Save", for: .normal)
        segueBack.backgroundColor = UIColor.init(ciColor: CIColor.white)
        
        arcanineButtons[1].setTitleColor(UIColor.init(ciColor: CIColor.init(red: 1, green: 0.5, blue: 0)), for: .normal)
        feraligatrButtons[1].setTitleColor(UIColor.init(ciColor: CIColor.init(red: 0, green: 0, blue: 0.5)), for: .normal)
        serperiorButtons[1].setTitleColor(UIColor.init(ciColor: CIColor.init(red: 0, green: 0.5, blue: 0)), for: .normal)
        
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func segueButton(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func petSelect(_ sender: UIButton) {
        switch sender.tag {
        case 0...1:
            print("Arcanine")
            delegate?.setNewPlayerPet(self, Arcanine())
            segueBack.backgroundColor = UIColor.init(ciColor: CIColor.init(red: 1, green: 0.5, blue: 0))
        case 2...3:
            print("Feraligatr")
            delegate?.setNewPlayerPet(self, Feraligatr())
            segueBack.backgroundColor = UIColor.init(ciColor: CIColor.init(red: 0, green: 0, blue: 0.5))
        case 4...5:
            print("Serperior")
            delegate?.setNewPlayerPet(self, Serperior())
            segueBack.backgroundColor = UIColor.init(ciColor: CIColor.init(red: 0, green: 0.5, blue: 0))
        default:
            print("Other Pet")
        }
        
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        if segue.destination is ViewController {
//            let vc = segue.destination as? ViewController
//        }
//    }
    

}
