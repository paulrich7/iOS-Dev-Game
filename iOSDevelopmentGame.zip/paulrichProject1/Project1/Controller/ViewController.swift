//
//  ViewController.swift
//  Project1
//
//  Created by user157788 on 9/13/19.
//  Copyright © 2019 paulrich. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var p1Img = UIImage(named: "cow")
    var p2Img = UIImage(named: "pikachu")
    var backImage = "grass.jpgß"
    
    var ownedPet: Pet? = nil
    var wildPet: Pet? = nil
    
    @IBOutlet weak var pImage: UIImageView!
    @IBOutlet weak var eImage: UIImageView!
    
    @IBOutlet weak var pHealth: UILabel!
    @IBOutlet weak var eHealth: UILabel!
    
    @IBOutlet weak var eStatus: UILabel!
    @IBOutlet weak var pStatus: UILabel!
    
    @IBOutlet weak var tlButton: UIButton!
    @IBOutlet weak var blButton: UIButton!
    @IBOutlet weak var trButton: UIButton!
    @IBOutlet weak var brButton: UIButton!
    
    @IBOutlet weak var eHealthBar: UIProgressView!
    @IBOutlet weak var pHealthBar: UIProgressView!
    
    @IBOutlet weak var EndLabel: UILabel!
    
    enum Attacks:Int {
        case fast = 1
        case slow
        case bstA
        case bstD
    }
    
    var player1:Player = Player.init(hp: 100, atk: 0, def: 0, spd: 0)
    var player2:Player = Player.init(hp: 100, atk: 0, def: 0, spd: 0)
    
    lazy var conflict = Conflict(ownedPet!, wildPet!)
    
    var p1HPInc: Float = 100.0
    var p2HPInc: Float = 100.0
    
    var p1HP = 100 {
        didSet {
            pHealthBar.setProgress(Float(p1HP) / p1HPInc, animated: true)
            pHealth.text = "Health: " + String(p1HP)
            if p1HP <= 0 {
                reset(w: false)
            }
            switch p1HP {
            case _ where Float(p1HP) < (p1HPInc * 0.2):
                pHealthBar.progressTintColor = UIColor(ciColor: CIColor.red)
            case _ where Float(p1HP) < (p1HPInc * 0.5):
                pHealthBar.progressTintColor = UIColor(ciColor: CIColor.yellow)
            default:
                pHealthBar.progressTintColor = UIColor(ciColor: CIColor.green)
            }
            
        }
    }
    var p2HP = 100 {
        didSet {
            eHealthBar.setProgress(Float(p2HP) / p2HPInc, animated: true)
            eHealth.text = "Health: " + String(p2HP)
            if p2HP <= 0 {
                reset(w: true)
            }
            switch p2HP {
            case _ where Float(p2HP) < (p2HPInc * 0.2):
                eHealthBar.progressTintColor = UIColor(ciColor: CIColor.red)
            case _ where Float(p2HP) < (p2HPInc * 0.5):
                eHealthBar.progressTintColor = UIColor(ciColor: CIColor.yellow)
            default:
                eHealthBar.progressTintColor = UIColor(ciColor: CIColor.green)
            }
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        pImage.image = ownedPet?.image
        eImage.image = wildPet?.image
        
        p1HPInc = Float((ownedPet?.calcRealHP()!)!)
        p2HPInc = Float((wildPet?.calcRealHP()!)!)
        
        p1HP = (ownedPet?.calcRealHP()!)!
        p2HP = (wildPet?.calcRealHP()!)!
        
        
        pImage.layer.cornerRadius = 20
        eImage.layer.cornerRadius = 20
        
        pStatus.text = "Fight!"
        eStatus.text = "Fight!"
        pHealthBar.progress = 1.00
        eHealthBar.progress = 1.00
        
        tlButton.setTitle(ownedPet?.m1?.name, for: .normal)
        tlButton.layer.cornerRadius = 10
        tlButton.backgroundColor = UIColor.init(ciColor: (ownedPet?.m1!.color)!)
        trButton.setTitle(ownedPet?.m2?.name, for: .normal)
        trButton.layer.cornerRadius = 10
        trButton.backgroundColor = UIColor.init(ciColor: (ownedPet?.m2!.color)!)
        blButton.setTitle(ownedPet?.m3?.name, for: .normal)
        blButton.layer.cornerRadius = 10
        blButton.backgroundColor = UIColor.init(ciColor: (ownedPet?.m3!.color)!)
        brButton.setTitle(ownedPet?.m4?.name, for: .normal)
        brButton.layer.cornerRadius = 10
        brButton.backgroundColor = UIColor.init(ciColor: (ownedPet?.m4!.color)!)
        
        EndLabel.layer.cornerRadius = 10
        
        pStatus.layer.masksToBounds = true
        pStatus.layer.cornerRadius = 10.0
        
        eStatus.layer.masksToBounds = true
        eStatus.layer.cornerRadius = 10.0
        
        pHealth.layer.masksToBounds = true
        pHealth.layer.cornerRadius = 10.0
        
        eHealth.layer.masksToBounds = true
        eHealth.layer.cornerRadius = 10.0
        
        UIGraphicsBeginImageContext(self.view.frame.size)
        UIImage(named: backImage)?.draw(in: self.view.bounds)

        if let image = UIGraphicsGetImageFromCurrentImageContext(){
            UIGraphicsEndImageContext()
            self.view.backgroundColor = UIColor(patternImage: image)
        }else{
            UIGraphicsEndImageContext()
            debugPrint("Image not available")
        }
    }
    
    @IBAction func TLButton(_ sender: UIButton) {
        conflict.setMove1(ownedPet?.m1)
        pStatus.text = ownedPet?.m1?.name
        pStatus.backgroundColor = sender.backgroundColor
        pStatus.textColor = UIColor.init(ciColor: CIColor.white)
        SimEnemyAction()
        let first = conflict.setConflict()
        let delay = DispatchTime.now() + .seconds(1)
        if !first {
            p1HP = Int((ownedPet?.actHP)!)
            if p1HP > 0 {
                DispatchQueue.main.asyncAfter(deadline: delay) {
                    self.p2HP = Int((self.wildPet?.actHP)!)
                }
            }
        }
        else {
            p2HP = Int((wildPet?.actHP)!)
            if p2HP > 0 {
                DispatchQueue.main.asyncAfter(deadline: delay) {
                    self.p1HP = Int((self.ownedPet?.actHP)!)
                }
            }
        }
    }
    
    @IBAction func BLButton(_ sender: UIButton) {
        conflict.setMove1(ownedPet?.m3)
        pStatus.text = ownedPet?.m3?.name
        pStatus.backgroundColor = sender.backgroundColor
        pStatus.textColor = UIColor.init(ciColor: CIColor.white)
        SimEnemyAction()
        let first = conflict.setConflict()
        let delay = DispatchTime.now() + .seconds(1)
        if !first {
            p1HP = Int((ownedPet?.actHP)!)
            if p1HP > 0 {
                DispatchQueue.main.asyncAfter(deadline: delay) {
                    self.p2HP = Int((self.wildPet?.actHP)!)
                }
            }
        }
        else {
            p2HP = Int((wildPet?.actHP)!)
            if p2HP > 0 {
                DispatchQueue.main.asyncAfter(deadline: delay) {
                    self.p1HP = Int((self.ownedPet?.actHP)!)
                }
            }
        }
    }
    
    @IBAction func TRButton(_ sender: UIButton) {
        conflict.setMove1(ownedPet?.m2)
        pStatus.text = ownedPet?.m2?.name
        pStatus.backgroundColor = sender.backgroundColor
        pStatus.textColor = UIColor.init(ciColor: CIColor.white)
        SimEnemyAction()
        let first = conflict.setConflict()
        let delay = DispatchTime.now() + .seconds(1)
        if !first {
            p1HP = Int((ownedPet?.actHP)!)
            if p1HP > 0 {
                DispatchQueue.main.asyncAfter(deadline: delay) {
                    self.p2HP = Int((self.wildPet?.actHP)!)
                }
            }
        }
        else {
            p2HP = Int((wildPet?.actHP)!)
            if p2HP > 0 {
                DispatchQueue.main.asyncAfter(deadline: delay) {
                    self.p1HP = Int((self.ownedPet?.actHP)!)
                }
            }
        }
    }
    
    @IBAction func BRButton(_ sender: UIButton) {
        conflict.setMove1(ownedPet?.m4)
        pStatus.text = ownedPet?.m4?.name
        pStatus.backgroundColor = sender.backgroundColor
        pStatus.textColor = UIColor.init(ciColor: CIColor.white)
        SimEnemyAction()
        let first = conflict.setConflict()
        let delay = DispatchTime.now() + .seconds(1)
        if !first {
            p1HP = Int((ownedPet?.actHP)!)
            if p1HP > 0 {
                DispatchQueue.main.asyncAfter(deadline: delay) {
                    self.p2HP = Int((self.wildPet?.actHP)!)
                }
            }
        }
        else {
            p2HP = Int((wildPet?.actHP)!)
            if p2HP > 0 {
                DispatchQueue.main.asyncAfter(deadline: delay) {
                    self.p1HP = Int((self.ownedPet?.actHP)!)
                }
            }
        }
    }
    
    func SimEnemyAction() -> Void {
        eStatus.textColor = UIColor.init(ciColor: CIColor.white)
        let rand = Int.random(in: 1...4)
        switch rand {
        case 1:
            conflict.setMove2(wildPet?.m1)
            eStatus.text = wildPet?.m1?.name
            eStatus.backgroundColor = UIColor.init(ciColor: wildPet!.m1!.color)
        case 2:
            conflict.setMove2(wildPet?.m2)
            eStatus.text = wildPet?.m2?.name
            eStatus.backgroundColor = UIColor.init(ciColor: wildPet!.m2!.color)
        case 3:
            conflict.setMove2(wildPet?.m3)
            eStatus.text = wildPet?.m3?.name
            eStatus.backgroundColor = UIColor.init(ciColor: wildPet!.m3!.color)
        case 4:
            conflict.setMove2(wildPet?.m4)
            eStatus.text = wildPet?.m4?.name
            eStatus.backgroundColor = UIColor.init(ciColor: wildPet!.m4!.color)
        default:
            print("Error: Invalid Attack ID")
            return
        }
    }
    
    func reset(w: Bool) {
        EndLabel.backgroundColor = UIColor.init(ciColor: CIColor.white)
        EndLabel.textColor = UIColor.init(ciColor: CIColor.black)
        if w {
            EndLabel.text = "You won the encounter using " + ownedPet!.name + "!"
        }
        else {
            EndLabel.text = "You lost the encounter using " + ownedPet!.name + "."
        }
        let delay = DispatchTime.now() + .seconds(3)
        DispatchQueue.main.asyncAfter(deadline: delay) {
            self.dismiss(animated: true, completion: nil)
        }
    }
    
}

