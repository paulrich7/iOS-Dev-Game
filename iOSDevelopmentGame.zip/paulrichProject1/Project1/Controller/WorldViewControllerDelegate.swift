//
//  WorldViewControllerDelegate.swift
//  Project1
//
//  Created by user157788 on 12/10/19.
//  Copyright © 2019 paulrich. All rights reserved.
//

import Foundation

protocol WorldViewControllerDelegate {
    func setNewPlayerPet(_ controller: MenuViewController, _ pet: Pet)
}
